"""ATLAS package."""
